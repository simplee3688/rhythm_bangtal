﻿#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <bangtal.h>
#include <stdlib.h>

//주석에서 블럭은 노트와 같은말이다

#define SPEED 4                 //블럭 낙하기본속도

#define STARTY 750              //시작 y좌표




int count = 0;                  //블럭 생성용 프레임 카운터
int count_brick = 0;            //블럭 몇개 생성했는가
int score_int = 0;              //점수 저장소
int FFFF = 15;                  //FFFF 프레임 마다 블럭 생성
int boomOn = 0;                 //이펙트 온오프기
bool first = 0;                 //타이머 콜백이 처음이루어졌는가

float FRAME = 0.02f;            //델타타임 , 노말 0.02 , 하드 0.01

SceneID page1;                  //배경

TimerID mm;                     //타임루프를 위한 타이머
TimerID score;                  //점수를 올리는 타이머
ObjectID b[15];                 //오브젝트 풀링을 할 블럭 수 / 원래 15이상 일 경우를 고려해서 15가 넘어간다면 새로 오브젝트틀 생성해야 하지만 편의상 15로 설정
int locate[15][2];              //블럭 위치
ObjectID key_a;                 //키보드
ObjectID key_s;
ObjectID key_d;
ObjectID here;                  //판정바의 시각적 위치
ObjectID retry;                 
ObjectID getout;               
ObjectID boom;                  //키보드 이펙트
ObjectID mode , mode2;          //난이도 선택
int whereme=0;                  //게임 진행 상황을 나타내는 변수
int slide_note = 0;             //처음 튜토리얼 시 사용
ObjectID right;                 //튜토시 방향
ObjectID left;


void randomBoom();              //reseter에서 쓰기위해 끌어옴

void reseter()                  //게임 시작및 재시작
{
    hideObject(right);          //오브젝트 초기화 변수 초기상태로 재설정
    hideObject(left);
    hideObject(retry);
    hideObject(getout);
    whereme = 1;
    FFFF = 15;
    boomOn = 0;
    score_int = 0;
    setTimer(score, score_int);
    randomBoom();
    scaleObject(boom, 1.0f);
    showObject(boom);
    count = 0;
    count_brick = 0;
    first = 1;                  //타이머 콜백이 처음실행 되는지 확인

    for (int j = 0; j < 15; j++)   //블럭 재설정
    {
        locate[j][0] = 0;
        locate[j][1] = 0;


        hideObject(b[j]);

    }
    showObject(here);           //오브젝트 보이기
    showObject(key_a);
    showObject(key_s);
    showObject(key_d);
    increaseTimer(mm, 3.0f);    //리셋 후 3초뒤 시작
    startTimer(mm);             
    showTimer(mm);
    
}

void checkAndShowNote()              //튜토리얼 슬라이딩 노트
{
                          
    switch (slide_note)
    {
        
    case 0 :
        showMessage("화살표를 클릭해 설명을 읽어보세요");
        break;

    case 1:
        showMessage("기본적인 리듬게임입니다 , 음악은 없습니다");
        break;

    case 2:
        showMessage("노트가 떨어질 때 A S D 를 이용하여 받으면 됩니다");
        break;

    case 3:
        showMessage("노트 1개를 받을 때마다 점수가 1점씩 오릅니다");
        break;

    case 4:
        showMessage("난이도를 선택해주세요.        주의 : 게임을 종료하기 전까지 변경할 수 없음"); //난이도 선택
        showObject(mode);
        showObject(mode2);
        hideObject(right);
        hideObject(left);
        break;

    

        default:
            break;
    }
}




void printover()                                //게임 오버 처리
{
    char printing[100] = "aaa";
    sprintf(printing, "GAMEOVER                                             점수 : %d", score_int);       //화면을 가려서 멀리 띄움
    hideTimer();
    showMessage(printing);
    showObject(retry);
    showObject(getout);
    whereme = 2;                                //상태변경
    first = 1;                                  //키보드 비활성화 및 이미지 재설정
    setObjectImage(key_a, "key_A.png"); 
    setObjectImage(key_s, "key_S.png");
    setObjectImage(key_d, "key_D.png");
}

void gameover(int x)                    //블럭이 판정범위 바깥으로 넘어갔을시 게임오버 체크
{
    if (locate[x][1] < 170)
    {
        printover();
    }

}

void del_brick(int x)                   //인자 x에 해당하는 좌표에 있는 블럭을 없애는 함수
{
    int checker = 0;
    for (int i = 0; i < 15; i++)
    {
        if (locate[i][0] == x && locate[i][1] >190 && locate[i][1] < 225)               //블럭 x좌표가 인자 x고 y좌표가 판정 범위 내에 있는가
        {
            checker++;
            locate[i][0] = 0;
            hideObject(b[i]);
            score_int ++;
            setTimer(score, score_int);
            if (score_int % 10==0 && FFFF > 12)
            {
                FFFF--;
            }
        }
    }
    if(checker == 0)                                    //하나라도 있으면 위에서 체커가 ++되서 이 조건에 안걸린다. 즉 잘못 누르면 게임오버
    {
        printover();
    }
}


int find_blank()                                    //오브젝트풀링을 위한 사용되고 있지 않는 블럭 찾기 // 사용되지 않음을 x좌표 0으로 정의함
{
    for (int i = 0; i < 15; i++)
    {
        if (locate[i][0] == 0)
        {
            //printf("%d\n", i);
            return i;
        }
    }
}


void create_brick()                                 //떨어지는 블럭 생성
{
    if (rand() % 5 != 1 && whereme ==1)             //확률 상 빈칸 뚫림 //whereme 1은 게임 진행 중을 의미
    {
        count_brick++;
        int i;
        int random;
        i = find_blank();

        random = rand() % 3;                        //확률에 따라서 ASD 중 하나의 x좌표에 배치
        if (random == 0)
        {
            locate[i][0] = 610;
        }
        else if (random == 1)
        {
            locate[i][0] = 510;
        }
        else
        {
            locate[i][0] = 710;
        }

        locate[i][1] = STARTY;                                      //시작 y좌표로 올려줌
        locateObject(b[i], page1, locate[i][0], locate[i][1]);
        showObject(b[i]);                                           //활성화
    }

}

void randomBoom()                                                   //확률에 따라 키보드 이펙트의 이미지를 바꿔줌
{
    int a = rand() % 7;
    switch (a)
    {
    case 0:
        setObjectImage(boom, "boom0.png");
        break;
    case 1:
        setObjectImage(boom, "boom1.png");
        break;
    case 2:
        setObjectImage(boom, "boom2.png");
        break;
    case 3:
        setObjectImage(boom, "boom3.png");
        break;
    case 4:
        setObjectImage(boom, "boom4.png");
        break;
    case 5:
        setObjectImage(boom, "boom5.png");
        break;
    case 6:
        setObjectImage(boom, "boom6.png");
        break;
    default:                                                        //그럴리 없지만 넣어둠
        setObjectImage(boom, "boom6.png");
        break;
    }
    
}


void renderingAndDown()                                             //블럭을 떨구고 키보드 이펙트를 작용하는 함수
{

    if (boomOn == 7)                                                //키보드 입력시 일정 프레임동안 확대 후 다시 축소
    {
        randomBoom();
        if (rand() % 3 != 0) scaleObject(boom, 1.5f);
        else scaleObject(boom, 1.8f);
  
    }

    if (boomOn != 0)
    {
        boomOn--;
    }
    
    else
    {
        scaleObject(boom, 1.0f);
    }

    for (int j = 0; j < 15; j++)                                    //비활성화 (x좌표가 0)인 블럭을 제외하고 일정하게 떨굼
    {


        if (locate[j][0] != 0 && whereme==1)
        {

            locateObject(b[j], page1, locate[j][0], locate[j][1]);
            locate[j][1] = locate[j][1] - (SPEED + int(count_brick / 14));                  //블럭이 14개 떨어질 때 마다 강하 속도 증가
            gameover(j);                                                                    //블럭이 판정범위 이하로 내려가서 게임이 끝나는 상황인가
            
        }
    }
    

}




void keyBoardCallback(KeyCode c, KeyState s)                                               //키보드 콜백 키보드 이펙트 관리
{
    

    if (first) return;                                                                     //게임 시작 전 대기시간 동안은 비활성화

    if (s == KeyState::KEY_PRESSED)                                                        //키보드 이펙트 켜기
    {
        boomOn = 7;
    }
    
    if(c == KeyCode :: KEY_A)                                                              //이미지를 바꿔서 누르고 있다를 표시해줌
    {
        if (s == KeyState::KEY_PRESSED) 
        {

            setObjectImage(key_a, "key_A_pushed.png");
            del_brick(510);
        }
        else
        {
            setObjectImage(key_a, "key_A.png");
        }
        
    }
    if (c == KeyCode::KEY_S)
    {
        if (s == KeyState::KEY_PRESSED)
        {
            setObjectImage(key_s, "key_S_pushed.png");
            del_brick(610);
        }
        else
        {
            setObjectImage(key_s, "key_S.png");
        }

    }
    if (c == KeyCode::KEY_D)
    {
        if (s == KeyState::KEY_PRESSED)
        {
            setObjectImage(key_d, "key_D_pushed.png");
            del_brick(710);
        }
        else
        {
            setObjectImage(key_d, "key_D.png");
        }

    }
    
}


void mouseCallback(ObjectID obj, int x, int y, MouseAction act)         //마우스 콜백 , 잡다하다
{
    if (obj == getout)                                                  //나가기
    {
        endGame();
    }
    if (obj == retry)                                                   //재시작
    {
        reseter();
    }
    if (obj == right)                                                   //튜토리얼 오른쪽 왼쪽
    {
        
        slide_note++;
        checkAndShowNote();
     
        
    }
    if (obj == left)
    {
        if (slide_note != 0)                                            //오른쪽은 계속가면 시작인데 왼쪽은 계속 못감
        {
            slide_note--;
            checkAndShowNote();
        }
        
    }

    if (obj == mode)                                                    //기본 모드 선택시 : 델타타임을 0.02f
    {
        FRAME = 0.02f;
        hideObject(mode);
        hideObject(mode2);
        reseter();
    }
    if (obj == mode2)                                                   //어려움 모드 선택시 : 델타타임을 0.01f 사실상 기본모드의 2배가 된다
    {
        FRAME = 0.01f;
        hideObject(mode);
        hideObject(mode2);
        reseter();
    }
}


void timerCallback(TimerID timer)                                       //타이머 콜백
{
    

    if (first)                                                          //타이머 콜백이 처음이라면 기존의 3..2..1.. 세는 타이머 숨기고 점수 표기용 타이머로 전호나
    {
        first = 0;
        hideTimer();
        showTimer(score);
    }

    if (timer == mm && whereme == 1)                                    //타임루프
    {
        
        increaseTimer(timer, FRAME);
        startTimer(mm);

    }

    renderingAndDown();                                                 //블럭 강하 함수
    

    count++;                                                            //몇 프레임 지났나? 블럭을 생성하기 위해 사용됨

    if (count > FFFF)                                                   //일정 프레임마다 블럭 생성
    {
        create_brick();
        count = 0;
    }
    if (whereme == 2)                                                   //게임오버 화면전환
    {
        showObject(retry);
        showObject(getout);
        hideTimer();
    }


}

int main()
{
    int test_space = 14;                                                 
    
    setGameOption(GameOption::GAME_OPTION_INVENTORY_BUTTON, false);     //그래픽 부분만 쓰기에 죄다 비활성화
    setGameOption(GameOption::GAME_OPTION_MESSAGE_BOX_BUTTON, false);
    setGameOption(GameOption::GAME_OPTION_ROOM_TITLE, false);

    for (int j = 0; j < 15; j++)                                        //오브젝트풀링을 위한 블럭 생성
    {
        locate[j][0] = 0;
        locate[j][1] = 0;
        b[j] = createObject("brick.png");
        scaleObject(b[j], 0.5f);
        hideObject(b[j]);

    }
    

    

    setMouseCallback(mouseCallback);                                    //콜백 등록 및 배경설정
    setKeyboardCallback(keyBoardCallback);
    setTimerCallback(timerCallback);
    page1 = createScene("room1", "backG.png");
    
    mm = createTimer(2.0f);                                             //타이머 등록
    startTimer(mm);
    

    score = createTimer(60.0f);


    right = createObject("right.png");                                  //이하 오브젝트 등록이기에 주석처리 x , createobject 재정의 할껄....
    scaleObject(right, 0.6f);
    locateObject(right, page1, 850, 500);
    showObject(right);


    left = createObject("left.png");
    scaleObject(left, 0.6f);
    locateObject(left, page1, 350, 500);
    showObject(left);


    key_a = createObject("key_A.png");
    scaleObject(key_a, 0.3f);
    locateObject(key_a, page1, 510 + test_space, 200);
  

    key_s = createObject("key_S.png");
    scaleObject(key_s, 0.3f);
    locateObject(key_s, page1, 610 + test_space, 200);
    

    key_d = createObject("key_D.png");
    scaleObject(key_d, 0.3f);
    locateObject(key_d, page1, 710 + test_space, 200);
    

    here = createObject("here.png");
    scaleObject(here, 0.4f);
    locateObject(here, page1, 438, 220);
    

    boom = createObject("boom0.png");
    locateObject(boom, page1, 150, 450);
    hideObject(boom);


    retry = createObject("retry.png");
    scaleObject(retry, 0.5f);
    locateObject(retry, page1, 200, 400);
    hideObject(retry);

    getout = createObject("getout.png");
    scaleObject(getout, 0.5f);
    locateObject(getout, page1, 1000, 400);
    hideObject(getout);

    mode = createObject("MODE_N.png");
    locateObject(mode, page1, 400, 350);
    

    mode2 = createObject("MODE_H.png");
    locateObject(mode2, page1, 740, 350);
    

    showMessage("화살표를 클릭해 설명을 읽어보세요");

    
    startGame(page1);

    

    


}
